package com.example.brawlanalyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val captureRequest = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        val heading = TextView(this).apply {
            text = "Brawl Analyzer — prototype"
            textSize = 24f
        }
        status = TextView(this).apply {
            text = "Status: not capturing"
            textSize = 16f
            setPadding(0, 28, 0, 28)
        }
        val start = Button(this).apply {
            text = "Start screen analysis"
            setOnClickListener { requestScreenCapture() }
        }
        val stop = Button(this).apply {
            text = "Stop capture"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                status.text = "Status: stopped"
            }
        }
        val note = TextView(this).apply {
            text = "This prototype only establishes screen-capture permission and frame reception. It does not yet detect Brawlers, bushes, ammo or projectiles."
            textSize = 14f
            setPadding(0, 28, 0, 0)
        }
        layout.addView(heading)
        layout.addView(status)
        layout.addView(start)
        layout.addView(stop)
        layout.addView(note)
        setContentView(layout)
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by Android, retained here for broad IDE compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                startForegroundService(serviceIntent)
                status.text = "Status: screen capture started (Android permission granted)"
            } else {
                status.text = "Status: screen capture permission was not granted"
            }
        }
    }
}
