BRAWL ANALYZER — ANDROID STARTER PROJECT

What this starter does:
- Creates a native Android project.
- Requests the official Android screen-capture permission.
- Starts a foreground MediaProjection service.
- Receives screen frames and closes them safely.

What it does NOT do yet:
- It does not recognize Brawlers, bushes, ammo, reload state or projectiles.
- It does not draw an overlay.
- It does not control the game.

Important:
- This is source code, not an APK.
- It has not been compiled or tested on a Samsung S22 in this environment.
- Building it requires an Android development environment with Android SDK 35 and JDK 17.
- Android shows its own screen-capture permission prompt. The user must approve each capture session.
